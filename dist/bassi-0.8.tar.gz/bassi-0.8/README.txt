# bassi: Bayesian Analysis for Slow Slip Inversions

bassi provides a framework for Bayesian Analysis of Fault Slip Inversions